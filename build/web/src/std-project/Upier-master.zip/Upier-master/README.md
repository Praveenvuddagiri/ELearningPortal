<h1 align="center">
  <br>
  <a href="https://github.com/cachecleanerjeet/Upier"><img src="https://firebasestorage.googleapis.com/v0/b/webtuhin.appspot.com/o/githubstatic%2Fupier.svg?alt=media&token=43bd247f-4737-40be-8a15-1a145a17652d" alt="Upier" width="300"></a>
</h1>
<h4 align="center"><a href="https://github.com/Redop1189/Upier" target="_blank">Upier</a> Is a Free and Secure Plartform to Create & Share UPI Payment's Link
 <br> <br> <a href="https://upier-pp.vercel.app/" align="center"><img src="https://img.shields.io/badge/create--a--payment--link-green?style=for-the-badge" alt="Upier" ></a>
</h4>

<br>
<br>

### Features:<br>

*i.  Totally Free.*<br>
*ii.  Support Amount Set.*<br>
*iii. Have QR Suppport for Scan & Pay.*<br>
*iv.  Works with all UPI App.*<br>
*v.  Cool and Easy to Use Interface.*<br>
*vi.   No Tracking Script & Totally Ads free.*<br>

### Best uses:<br>

*This will help Local Businesses to recieve their Payment via UPI Link. Because this is [MIT Licenced ](https://github.com/cachecleanerjeet/Upier/blob/master/LICENSE "MIT Licenced ")you can customize it however you need & impliment on your Business.*<br><br>

### Deploy: <br>
*Everthing is pre-configured, You can just deploy it on Vercel* <br>

- Fork this Repo
- Goto <tt>https://vercel.com</tt>
- Connect with your Forked Repo
- Deploy
<br>

**You can Customize it However you Like**👍. **But don't Forget to give a Footer Credit**😉.<br><br>


### Credits:
Idea from [Upayi](https://github.com/cyberboysumanjay/upayi "Upayi") by [Sumanjay](https://github.com/cyberboysumanjay/ "Sumanjay")<br>
Designed & Developed by [(Tuhin)](https://github.com/cachecleanerjeet "Me (Tuhin)")<br>
Redesigned & Redeveloped by [Me (Prathamesh)](https://github.com/Redop1189 "Me (Prathamesh)")

<br><br>

<h3 align="center"># Go Cashless</h3>
<p align="center"> <b>Made in 🇮🇳 for 🇮🇳</b></p>
<br><br>
<p align="center"> <b>My Website & Social</b></p>
<br>
<p align="center">
 <code>
   
 <a href="https://prathameshpawar.vercel.app/">
    <img alt="Website" width="35px" src="https://cdn.jsdelivr.net/gh/Redop1189/cdn/Brand-Logos/Website-logo.svg" />
  </a>  

<a href="https://www.facebook.com/">
    <img alt="Facebook" width="50px" src="https://cdn.jsdelivr.net/gh/Redop1189/cdn/Brand-Logos/facebook.svg" />
  </a>  

  <a href="https://www.instagram.com/prathameshpawar1189">
    <img alt="Instagram" width="50px" src="https://cdn.jsdelivr.net/gh/Redop1189/cdn/Brand-Logos/instagram.svg" />
  </a>

  <a href="https://www.youtube.com/">
    <img alt="YouTube" width="40px" src="https://cdn.jsdelivr.net/gh/Redop1189/cdn/Brand-Logos/youtube2.svg" />
  </a>

  <a href="https://www.google.com/">
    <img alt="Blogger" width="40px" src="https://cdn.jsdelivr.net/gh/Redop1189/cdn/Brand-Logos/mail-icon.svg" />
  </a>
  
</code> 
</p>
